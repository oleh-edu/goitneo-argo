import json
def handler(event, context):
    print("Validating data...")
    # умовна валідація
    result = {"validated": True, "details": "basic checks passed"}
    return {"statusCode": 200, "body": json.dumps(result), "input": event}
